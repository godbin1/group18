package com.group18.ssm.jiaoyou.dto;

import lombok.Data;


@Data
public class UploadFileVO {

    private String src;

    private String title;

}
