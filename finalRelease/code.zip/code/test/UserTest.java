package com.example.game;

import com.example.game.entity.user.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserTest {

    private User user;

    @BeforeEach
    void setUp() {
        user = new User(1L,"john_doe", "password", "john.doe@example.com");
    }

    @Test
    void testGetId() {
        Assertions.assertEquals(1, user.getId());
    }

    @Test
    void testGetUsername() {
        Assertions.assertEquals("john_doe", user.getUsername());
    }

    @Test
    void testSetUsername() {
        user.setUsername("jane_doe");
        Assertions.assertEquals("jane_doe", user.getUsername());
    }

    @Test
    void testGetPassword() {
        Assertions.assertEquals("password", user.getPassword());
    }

    @Test
    void testSetPassword() {
        user.setPassword("new_password");
        Assertions.assertEquals("new_password", user.getPassword());
    }

    @Test
    void testGetEmail() {
        Assertions.assertEquals("john.doe@example.com", user.getEmail());
    }

    @Test
    void testSetEmail() {
        user.setEmail("jane.doe@example.com");
        Assertions.assertEquals("jane.doe@example.com", user.getEmail());
    }
}