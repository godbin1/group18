package com.group18.ssm.youxijiaoyou.dto;

import lombok.Data;


@Data
public class UploadFileVO {

    private String src;

    private String title;

}
